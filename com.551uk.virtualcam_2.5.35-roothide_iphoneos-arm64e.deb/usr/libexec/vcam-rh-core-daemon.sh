#!/bin/sh
# RootHide loader for Virtual Cam's mediaserverd components.
DIR="/rootfs/var/mobile/Media/DCIM"
[ -d "$DIR" ] || DIR="/var/mobile/Media/DCIM"
CONFIG="$DIR/vcam.plist"

JBROOT="$(/usr/bin/jbroot 2>/dev/null || jbroot 2>/dev/null || true)"
JBROOT="${JBROOT%/}"
[ -n "$JBROOT" ] || exit 1

OPA="$JBROOT/basebin/opainject"
CORE="$JBROOT/Library/MobileSubstrate/DynamicLibraries/VCamCore.dylib"
CAUDIO="$JBROOT/Library/MobileSubstrate/DynamicLibraries/VCamCameraAudio.dylib"
LAUNCHCTL="$JBROOT/usr/bin/launchctl"

find_msd_pid() {
    _pid=""
    if [ -x "$LAUNCHCTL" ]; then
        _out="$($LAUNCHCTL print system/com.apple.mediaserverd 2>/dev/null || true)"
        _pid="$(printf '%s\n' "$_out" | sed -n 's/^[[:space:]]*pid = \([0-9][0-9]*\).*/\1/p' 2>/dev/null | head -n 1 2>/dev/null)"
        if [ -z "$_pid" ]; then
            _out="$($LAUNCHCTL list com.apple.mediaserverd 2>/dev/null || true)"
            _pid="$(printf '%s\n' "$_out" | sed -n 's/.*"PID"[[:space:]]*=[[:space:]]*\([0-9][0-9]*\).*/\1/p' 2>/dev/null | head -n 1 2>/dev/null)"
        fi
    fi
    if [ -z "$_pid" ]; then
        _ps="$(command -v ps 2>/dev/null || true)"
        if [ -n "$_ps" ]; then
            _pid="$($_ps -A -o pid= -o comm= 2>/dev/null | while read p c rest; do
                case "$c" in mediaserverd|*/mediaserverd) echo "$p"; break;; esac
            done)"
        fi
    fi
    printf '%s' "$_pid"
}

last_cfg=""
[ -f "$CONFIG" ] && last_cfg="$(cat "$CONFIG" 2>/dev/null || true)"
loaded_pid=""

while :; do
    pid="$(find_msd_pid)"
    if [ -n "$loaded_pid" ] && [ "$pid" != "$loaded_pid" ]; then
        loaded_pid=""
    fi

    cur_cfg=""
    [ -f "$CONFIG" ] && cur_cfg="$(cat "$CONFIG" 2>/dev/null || true)"

    if [ "$cur_cfg" != "$last_cfg" ]; then
        last_cfg="$cur_cfg"

        # Fix 4 only became reliable after the Camera selection had
        # committed and the capture graph was active.
        sleep 2
        pid="$(find_msd_pid)"

        if [ -n "$pid" ] && [ "$pid" != "$loaded_pid" ] && [ -x "$OPA" ] && [ -r "$CORE" ]; then
            if "$OPA" "$pid" "$CORE" >/dev/null 2>&1; then
                [ -r "$CAUDIO" ] && "$OPA" "$pid" "$CAUDIO" >/dev/null 2>&1 || true
                loaded_pid="$pid"
            fi
        fi
    fi

    sleep 1
done
