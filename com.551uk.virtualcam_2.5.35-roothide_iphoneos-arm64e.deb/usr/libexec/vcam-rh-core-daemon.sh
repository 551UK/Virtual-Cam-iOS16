#!/bin/sh
# RootHide loader for Virtual Cam's mediaserverd components.
DIR="/rootfs/var/mobile/Media/DCIM"
[ -d "$DIR" ] || DIR="/var/mobile/Media/DCIM"
CONFIG="$DIR/vcam.plist"

JBROOT="$(/usr/bin/jbroot 2>/dev/null || jbroot 2>/dev/null || true)"
JBROOT="${JBROOT%/}"
[ -n "$JBROOT" ] || exit 1

OPA="$JBROOT/basebin/opainject"
CORE="$JBROOT/Library/MobileSubstrate/DynamicLibraries/VCamCore.dylib"
CAUDIO="$JBROOT/Library/MobileSubstrate/DynamicLibraries/VCamCameraAudio.dylib"
LAUNCHCTL="$JBROOT/usr/bin/launchctl"

find_msd_pid() {
    _pid=""
    if [ -x "$LAUNCHCTL" ]; then
        _out="$($LAUNCHCTL print system/com.apple.mediaserverd 2>/dev/null || true)"
        _pid="$(printf '%s\n' "$_out" | sed -n 's/^[[:space:]]*pid = \([0-9][0-9]*\).*/\1/p' 2>/dev/null | head -n 1 2>/dev/null)"
        if [ -z "$_pid" ]; then
            _out="$($LAUNCHCTL list com.apple.mediaserverd 2>/dev/null || true)"
            _pid="$(printf '%s\n' "$_out" | sed -n 's/.*"PID"[[:space:]]*=[[:space:]]*\([0-9][0-9]*\).*/\1/p' 2>/dev/null | head -n 1 2>/dev/null)"
        fi
    fi
    printf '%s' "$_pid"
}

loaded_pid=""
while :; do
    if [ -f "$CONFIG" ] && [ -x "$OPA" ] && [ -r "$CORE" ]; then
        pid="$(find_msd_pid)"
        if [ -n "$pid" ] && [ "$pid" != "$loaded_pid" ]; then
            sleep 2
            pid="$(find_msd_pid)"
            if [ -n "$pid" ] && [ "$pid" != "$loaded_pid" ]; then
                "$OPA" "$pid" "$CORE" >/dev/null 2>&1 && {
                    [ -r "$CAUDIO" ] && "$OPA" "$pid" "$CAUDIO" >/dev/null 2>&1 || true
                    loaded_pid="$pid"
                }
            fi
        fi
    fi
    sleep 2
done
